-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 07, 2019 at 03:13 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cmpt`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `p_id` varchar(50) NOT NULL,
  `p_name` varchar(50) NOT NULL,
  `d_category` varchar(50) NOT NULL,
  `d_name` varchar(50) NOT NULL,
  `date` varchar(19) NOT NULL,
  `time` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`p_id`, `p_name`, `d_category`, `d_name`, `date`, `time`) VALUES
('1001', 'John', 'Gynaecology', 'Dr. Ishika', '27/03/2019', '5:30 pm'),
('1001', 'John', 'Heart', 'Dr. Shetty', '28/03/2019', '2:00 pm'),
('1002', 'Dalen', 'Family Consultant', 'Dr. Huda', '30/03/2019', '2:00 pm'),
('1002', 'Dalen', 'Gynaecology', 'Dr. Ishika', '30/03/2019', '6:30 pm'),
('1002', 'Dalen', 'Heart', 'Dr. Shetty', '02/04/2019', '11:00 am'),
('1002', 'Dalen', 'Family Consultant', 'Dr. Huda', '04/04/2019', '10:00 am'),
('1002', 'Dalen', 'Bone', 'Dr. Verna', '04/04/2019', '2:00 pm'),
('1002', 'Dalen', 'Gynaecology', 'Dr. Ishika', '05/04/2019', '11:30 am');

-- --------------------------------------------------------

--
-- Table structure for table `avail`
--

CREATE TABLE `avail` (
  `time` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `avail`
--

INSERT INTO `avail` (`time`) VALUES
('10:00 am'),
('10:30 am'),
('11:00 am'),
('11:30 am'),
('1:00 pm'),
('1:30 pm'),
('2:00 pm'),
('2:30 pm'),
('3:00 pm'),
('3:30 pm'),
('4:00 pm'),
('5:30 pm'),
('6:00 pm'),
('6:30 pm'),
('7:00 pm');

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE `doctor` (
  `d_id` varchar(50) NOT NULL,
  `d_pass` varchar(50) NOT NULL,
  `d_name` varchar(50) NOT NULL,
  `d_category` varchar(50) NOT NULL,
  `d_email` varchar(50) NOT NULL,
  `d_phone` bigint(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`d_id`, `d_pass`, `d_name`, `d_category`, `d_email`, `d_phone`) VALUES
('dr1001', '827ccb0eea8a706c4c34a16891f84e7b', 'Dr. Verna', 'Bone', 'drverna@gmail.com', 3062033669),
('dr1002', '827ccb0eea8a706c4c34a16891f84e7b', 'Dr. Shetty', 'Heart', 'drshetty@gmail.com', 0),
('dr1003', '827ccb0eea8a706c4c34a16891f84e7b', 'Dr. Philips', 'Bone', 'drphilips@gmail.com', 0),
('dr1004', '827ccb0eea8a706c4c34a16891f84e7b', 'Dr. Ishika', 'Gynaecology', 'drishika@gmail.com', 0),
('dr1005', '827ccb0eea8a706c4c34a16891f84e7b', 'Dr. Huda', 'Family Consultant', 'drhuda@gmail.com', 0);

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE `history` (
  `p_id` varchar(50) NOT NULL,
  `p_name` varchar(50) NOT NULL,
  `d_category` varchar(50) NOT NULL,
  `d_name` varchar(50) NOT NULL,
  `date` varchar(50) NOT NULL,
  `time` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`p_id`, `p_name`, `d_category`, `d_name`, `date`, `time`) VALUES
('1001', 'John', 'Bone', 'Dr. Verna', '15/03/2019', '4:00 pm'),
('1002', 'Dalen', 'Heart', 'Dr. Shetty', '17/03/2019', '10:30 am'),
('1002', 'Dalen', 'Family Consultant', 'Dr. Huda', '19/03/2019', '11:00 am'),
('1001', 'John', 'Bone', 'Dr. Verna', '27/03/2019', '6:00 pm'),
('1001', 'John', 'Bone', 'Dr. Verna', '27/03/2019', '6:00 pm'),
('1001', 'John', 'Bone', 'Dr. Verna', '27/03/2019', '6:00 pm'),
('1002', 'Dalen', 'Bone', 'Dr. Verna', '28/03/2019', '2:30 pm'),
('1001', 'John', 'Bone', 'Dr. Verna', '28/03/2019', '6:00 pm'),
('1001', 'John', 'Bone', 'Dr. Verna', '29/03/2019', '7:00 pm'),
('1001', 'John', 'Bone', 'Dr. Verna', '30/03/2019', '1:00 pm'),
('1001', 'John', 'Bone', 'Dr. Verna', '30/03/2019', '1:30 pm'),
('1001', 'John', 'Bone', 'Dr. Verna', '30/03/2019', '2:00 pm'),
('1002', 'Dalen', 'Bone', 'Dr. Verna', '31/03/2019', '10:00 am'),
('1002', 'Dalen', 'Bone', 'Dr. Verna', '31/03/2019', '10:00 am'),
('1002', 'Dalen', 'Bone', 'Dr. Verna', '04/04/2019', '10:30 am'),
('', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `p_id` varchar(50) NOT NULL,
  `number` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`p_id`, `number`) VALUES
('1001', 1),
('1001', 1),
('1001', 1),
('1001', 1),
('1001', 1),
('1001', 1),
('1001', 1),
('1001', 1),
('1001', 1),
('1001', 1),
('1001', 1),
('1001', 1),
('1001', 1),
('1001', 1);

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `p_name` varchar(50) NOT NULL,
  `p_id` varchar(50) NOT NULL,
  `p_pass` varchar(50) NOT NULL,
  `h_card` int(10) NOT NULL,
  `p_phone` bigint(12) NOT NULL,
  `p_email` varchar(50) NOT NULL,
  `p_address` varchar(100) NOT NULL,
  `p_gender` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`p_name`, `p_id`, `p_pass`, `h_card`, `p_phone`, `p_email`, `p_address`, `p_gender`) VALUES
('Dalen', '1002', '827ccb0eea8a706c4c34a16891f84e7b', 365985784, 3062589635, 'dalen@gmail.com', '91 Campus Dr,S7N5E8, Saskatoon,Sk                 ', 'male'),
('Ovi', '1003', '12345', 123456987, 3062033559, 'ovi01681730008@gmail.com', '91 Campus Dr,S7N5E8,Saskatoon,Sk', 'male'),
('Alavi', '1004', '12345', 125639874, 6399160975, 'alavisharar@gmail.com', '91 Campus Dr,S7N5E8,Saskatoon,Sk', 'female'),
('Hena', '1005', '12345', 256368479, 3065847896, 'hena@gmail.com', '91 Campus Dr,S7N5E8,Saskatoon,Sk', 'female'),
('saiduzzaman ovi', '1009', '12345', 123456789, 0, 'ovi01681730008@gmail.com', 'holding no', 'male'),
('Alavi Sharar', '1234', '12345', 123654987, 6399160971, 'alavisharar@gmail.com', 'BOX:198,103 CUMBERLAND AVENUE SOUTH', 'female'),
('Arindam', '1007', '12345', 123456789, 2033655544, 'chak@gmail.com', '35 campus dr, saskatoon', 'male'),
('John', '1001', '827ccb0eea8a706c4c34a16891f84e7b', 123456789, 3062033669, 'john@gmail.com', ' 128Saskatchewan hall\r\n91 campus drive  ', 'male');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
